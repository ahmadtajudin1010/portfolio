document.addEventListener("DOMContentLoaded", () => {

const toggle = document.getElementById("themeToggle");
if(!toggle) return;

/* ===== AUTO DETECT OS THEME ===== */

const systemDark = window.matchMedia("(prefers-color-scheme: dark)").matches;

/* ===== LOAD SAVED ===== */

let saved = localStorage.getItem("theme");

if(!saved){

saved = systemDark ? "dark" : "light";

}

applyTheme(saved);

/* ===== CLICK ===== */

toggle.onclick = () => {

const next =
document.body.classList.contains("light")
? "dark"
: "light";

applyTheme(next);

};

/* ===== APPLY ===== */

function applyTheme(mode){

document.body.classList.toggle("light", mode==="light");

localStorage.setItem("theme",mode);

toggle.textContent =
mode==="light" ? "☀️" : "🌙";

}

});
