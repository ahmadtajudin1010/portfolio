const videoGrid = document.getElementById("videoGrid");

for(let i=1;i<=100;i++){

const v = {
title:`Video Demo ${i}`,
channel:"MyTube",
views:"100K views",
src:"./video/loading-ps4.mp4"
};

const card = document.createElement("div");
card.className="video-card";

card.innerHTML=`
<div class="thumb">
<video src="${v.src}" muted loop></video>
</div>
<div style="padding:10px">
${v.title}
</div>
`;

card.onclick=()=>{
localStorage.setItem("currentVideo",JSON.stringify(v));
location.href="player.html";
};

videoGrid.appendChild(card);

}
