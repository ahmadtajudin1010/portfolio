const data = JSON.parse(localStorage.getItem("currentVideo"));
const player = document.getElementById("player");
const title = document.getElementById("title");
const meta = document.getElementById("meta");
if(data){
player.src = data.src;
title.textContent = data.title;
meta.textContent = `${data.channel} • ${data.views}`;
}else{
location.href = "index.html";
}