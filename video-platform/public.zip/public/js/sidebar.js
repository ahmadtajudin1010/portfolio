const menuBtn=document.getElementById("menuBtn");
const sidebar=document.getElementById("sidebar");
const overlay=document.getElementById("overlay");
const homeBtn=document.getElementById("homeBtn");

menuBtn.onclick=()=>{
sidebar.classList.toggle("hidden");
overlay.classList.toggle("hidden");
};

function close(){
sidebar.classList.add("hidden");
overlay.classList.add("hidden");
}

overlay.onclick=close;
homeBtn.onclick=close;
